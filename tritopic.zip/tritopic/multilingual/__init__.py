"""Multilingual support."""

from .detection import detect_corpus_language

__all__ = ["detect_corpus_language"]
