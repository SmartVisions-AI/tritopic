"""Language detection for document corpora."""

import random
from typing import Dict, List
from collections import Counter


def detect_corpus_language(documents: List[str], sample_size: int = 100) -> Dict:
    """Detect dominant language in corpus."""
    try:
        from langdetect import detect
    except ImportError:
        return {"dominant_language": "en", "confidence": 0.0}
    
    sample = random.sample(documents, min(sample_size, len(documents)))
    detected = []
    
    for doc in sample:
        try:
            if len(doc.strip()) > 20:
                detected.append(detect(doc))
        except:
            pass
    
    if not detected:
        return {"dominant_language": "en", "confidence": 0.0}
    
    counts = Counter(detected)
    dominant = counts.most_common(1)[0]
    
    return {
        "dominant_language": dominant[0],
        "confidence": dominant[1] / len(detected),
        "distribution": dict(counts)
    }
