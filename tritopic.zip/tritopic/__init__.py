"""
TriTopic: Tri-Modal Graph Topic Modeling with Iterative Refinement
"""

__version__ = "1.1.0"

from .model import TriTopic, Topic
from .config import TriTopicConfig, get_config

__all__ = [
    "TriTopic",
    "Topic", 
    "TriTopicConfig",
    "get_config",
]
