"""
TriTopic: Tri-Modal Graph Topic Modeling with Iterative Refinement
Main model class - Version 1.1.0
"""

import pickle
import warnings
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional, Union

import numpy as np
import pandas as pd
from scipy import sparse

from .config import TriTopicConfig, get_config


@dataclass
class Topic:
    """Represents a single topic with all metadata."""
    topic_id: int
    size: int
    keywords: List[str]
    keyword_scores: List[float]
    representative_docs: List[int]
    representative_texts: List[str]
    centroid: Optional[np.ndarray] = None
    label: Optional[str] = None
    archetypes: Optional[List[int]] = None
    archetype_texts: Optional[List[str]] = None
    
    def __repr__(self):
        kw = ", ".join(self.keywords[:5])
        lbl = f" ({self.label})" if self.label else ""
        return f"Topic {self.topic_id}{lbl}: [{kw}] (n={self.size})"


class TriTopic:
    """
    Tri-Modal Graph Topic Modeling with Iterative Refinement.
    
    Parameters
    ----------
    config : TriTopicConfig or str, optional
        Configuration object or preset name ('default', 'fast', 'quality', 'multilingual').
    **kwargs
        Override any config parameter directly.
    
    Examples
    --------
    >>> from tritopic import TriTopic
    >>> model = TriTopic(verbose=True)
    >>> topics = model.fit_transform(documents)
    """
    
    def __init__(self, config: Optional[Union[TriTopicConfig, str]] = None, **kwargs):
        # Load configuration
        if config is None:
            self.config = TriTopicConfig()
        elif isinstance(config, str):
            self.config = get_config(config)
        else:
            self.config = config
        
        # Apply kwargs overrides
        for key, value in kwargs.items():
            if hasattr(self.config, key):
                setattr(self.config, key, value)
            else:
                warnings.warn(f"Unknown config parameter: {key}")
        
        # Component placeholders
        self._embedding_engine = None
        self._graph_builder = None
        self._clusterer = None
        self._keyword_extractor = None
        self._representative_selector = None
        
        # Result attributes
        self.documents_: Optional[List[str]] = None
        self.embeddings_: Optional[np.ndarray] = None
        self.graph_: Optional[sparse.csr_matrix] = None
        self.topic_labels_: Optional[np.ndarray] = None
        self.topics_: Optional[List[Topic]] = None
        self.n_topics_: int = 0
        self.outlier_count_: int = 0
        self.detected_language_: Optional[str] = None
    
    def _log(self, msg: str, level: int = 1):
        """Print if verbose."""
        if self.config.verbose:
            print("   " * (level - 1) + msg)
    
    def _detect_language(self, documents: List[str]):
        """Detect corpus language."""
        try:
            from .multilingual.detection import detect_corpus_language
            result = detect_corpus_language(documents, self.config.language_detection_sample)
            self.detected_language_ = result["dominant_language"]
            self._log(f"Detected language: {self.detected_language_}", 2)
        except Exception:
            self.detected_language_ = "en"
            self._log("Language detection unavailable, defaulting to English", 2)
    
    def _initialize_components(self, documents: List[str]):
        """Initialize all processing components."""
        # Language detection
        if self.config.language == "auto":
            self._detect_language(documents)
        else:
            self.detected_language_ = self.config.language
        
        # Select embedding model
        emb_model = self.config.embedding_model
        if emb_model == "auto":
            emb_model = self.config.get_embedding_model_for_language(self.detected_language_)
            self._log(f"Selected model: {emb_model}", 2)
        
        # Embedding engine
        from .core.embeddings import EmbeddingEngine
        self._embedding_engine = EmbeddingEngine(
            model_name=emb_model,
            batch_size=self.config.embedding_batch_size,
            device=self.config.device  # Uses config.device
        )
        
        # Graph builder
        from .core.graph import MultiViewGraphBuilder
        self._graph_builder = MultiViewGraphBuilder(
            n_neighbors=self.config.n_neighbors,
            metric=self.config.metric,
            graph_type=self.config.graph_type,
            snn_weight=self.config.snn_weight,
            semantic_weight=self.config.semantic_weight,
            lexical_weight=self.config.lexical_weight,
            metadata_weight=self.config.metadata_weight,
            use_lexical=self.config.use_lexical_view,
            use_metadata=self.config.use_metadata_view,
            lexical_method=self.config.lexical_method,
            ngram_range=self.config.ngram_range
        )
        
        # Clusterer
        from .core.clustering import ConsensusLeiden
        self._clusterer = ConsensusLeiden(
            resolution=self.config.resolution,
            n_runs=self.config.n_consensus_runs,
            min_cluster_size=self.config.min_cluster_size,
            random_state=self.config.random_state
        )
        
        # Keyword extractor
        from .core.keywords import KeywordExtractor
        self._keyword_extractor = KeywordExtractor(
            method=self.config.keyword_method,
            n_keywords=self.config.n_keywords,
            language=self.detected_language_,
            ngram_range=self.config.ngram_range
        )
        
        # Representative selector with archetype support
        from .core.representatives import RepresentativeSelector
        self._representative_selector = RepresentativeSelector(
            method=self.config.representative_method,
            n_representatives=self.config.n_representative_docs,
            n_archetypes=self.config.n_archetypes,
            archetype_method=self.config.archetype_method
        )
    
    def fit(
        self,
        documents: List[str],
        embeddings: Optional[np.ndarray] = None,
        metadata: Optional[pd.DataFrame] = None
    ) -> "TriTopic":
        """
        Fit the topic model on documents.
        
        Parameters
        ----------
        documents : List[str]
            List of text documents.
        embeddings : np.ndarray, optional
            Pre-computed embeddings.
        metadata : pd.DataFrame, optional
            Document metadata for multi-view fusion.
        
        Returns
        -------
        self
        """
        self.documents_ = documents
        n_docs = len(documents)
        
        self._log(f"🚀 TriTopic: Fitting model on {n_docs} documents")
        mode = "iterative" if self.config.use_iterative_refinement else "single-pass"
        self._log(f"Config: {self.config.graph_type} graph, {mode} mode", 1)
        
        # Initialize components
        self._initialize_components(documents)
        
        # Step 1: Embeddings
        if embeddings is not None:
            self._log("→ Using provided embeddings", 1)
            self.embeddings_ = embeddings
        else:
            self._log(f"→ Generating embeddings ({self._embedding_engine.model_name})...", 1)
            self.embeddings_ = self._embedding_engine.encode(documents)
        
        # Step 2: Build graph
        if self.config.use_lexical_view:
            self._log("→ Building lexical similarity matrix...", 1)
        
        self.graph_ = self._graph_builder.build(self.embeddings_, documents, metadata)
        
        # Step 3: Clustering
        if self.config.use_iterative_refinement:
            self._log(f"→ Starting iterative refinement (max {self.config.max_iterations} iterations)...", 1)
            self._iterative_fit()
        else:
            self._log("→ Clustering...", 1)
            self.topic_labels_ = self._clusterer.fit_predict(self.graph_)
        
        # Step 4: Extract topics
        self._log("→ Extracting keywords and representative documents...", 1)
        self._extract_topics()
        
        # Summary
        self.n_topics_ = len([t for t in self.topics_ if t.topic_id >= 0])
        self.outlier_count_ = int(np.sum(self.topic_labels_ == -1))
        
        self._log(f"\n✅ Fitting complete!")
        self._log(f"Found {self.n_topics_} topics", 1)
        self._log(f"{self.outlier_count_} outlier documents ({100*self.outlier_count_/n_docs:.1f}%)", 1)
        
        return self
    
    def _iterative_fit(self):
        """Iterative clustering with embedding refinement."""
        from sklearn.metrics import adjusted_rand_score
        from .core.refinement import EmbeddingRefiner
        
        refiner = EmbeddingRefiner(strength=self.config.refinement_strength)
        current_emb = self.embeddings_.copy()
        prev_labels = None
        
        for i in range(self.config.max_iterations):
            self._log(f"Iteration {i + 1}...", 2)
            
            # Rebuild graph
            self.graph_ = self._graph_builder.build(current_emb, self.documents_, None)
            
            # Cluster
            labels = self._clusterer.fit_predict(self.graph_)
            
            # Check convergence
            if prev_labels is not None:
                ari = adjusted_rand_score(prev_labels, labels)
                self._log(f"ARI vs previous: {ari:.4f}", 3)
                if ari >= self.config.convergence_threshold:
                    self._log(f"✓ Converged at iteration {i + 1}", 2)
                    break
            
            # Refine
            current_emb = refiner.refine(current_emb, labels)
            prev_labels = labels.copy()
        
        self.embeddings_ = current_emb
        self.topic_labels_ = labels
    
    def _extract_topics(self):
        """Extract keywords, representatives, and archetypes for each topic."""
        self.topics_ = []
        
        for label in np.unique(self.topic_labels_):
            mask = self.topic_labels_ == label
            indices = np.where(mask)[0]
            docs = [self.documents_[i] for i in indices]
            embs = self.embeddings_[mask]
            
            # Keywords
            keywords, scores = self._keyword_extractor.extract(docs, self.documents_)
            
            # Representatives (including archetypes)
            rep = self._representative_selector.select(embs, docs, keywords, indices)
            
            # Centroid
            centroid = np.mean(embs, axis=0) if len(embs) > 0 else None
            
            self.topics_.append(Topic(
                topic_id=label,
                size=len(indices),
                keywords=keywords,
                keyword_scores=scores,
                representative_docs=rep.get('indices', list(indices[:self.config.n_representative_docs])),
                representative_texts=rep.get('texts', docs[:self.config.n_representative_docs]),
                centroid=centroid,
                archetypes=rep.get('archetype_indices'),
                archetype_texts=rep.get('archetype_texts')
            ))
        
        self.topics_.sort(key=lambda t: t.topic_id)
    
    def fit_transform(
        self,
        documents: List[str],
        embeddings: Optional[np.ndarray] = None,
        metadata: Optional[pd.DataFrame] = None
    ) -> np.ndarray:
        """Fit model and return topic assignments."""
        self.fit(documents, embeddings, metadata)
        return self.topic_labels_
    
    def transform(self, documents: List[str]) -> np.ndarray:
        """Assign topics to new documents."""
        if self.topics_ is None:
            raise ValueError("Model not fitted")
        
        new_emb = self._embedding_engine.encode(documents, show_progress=False)
        labels = []
        
        for emb in new_emb:
            best_topic = -1
            min_dist = float('inf')
            for t in self.topics_:
                if t.topic_id >= 0 and t.centroid is not None:
                    dist = np.linalg.norm(emb - t.centroid)
                    if dist < min_dist:
                        min_dist = dist
                        best_topic = t.topic_id
            labels.append(best_topic)
        
        return np.array(labels)
    
    def get_topic_info(self) -> pd.DataFrame:
        """Get topic summary as DataFrame."""
        if self.topics_ is None:
            raise ValueError("Model not fitted")
        
        return pd.DataFrame([{
            'Topic': t.topic_id,
            'Size': t.size,
            'Keywords': ', '.join(t.keywords[:5]),
            'Label': t.label or f"Topic {t.topic_id}",
            'Has_Archetypes': t.archetypes is not None and len(t.archetypes) > 0
        } for t in self.topics_])
    
    def get_topic(self, topic_id: int) -> Optional[Topic]:
        """Get specific topic by ID."""
        if self.topics_ is None:
            return None
        for t in self.topics_:
            if t.topic_id == topic_id:
                return t
        return None
    
    def get_document_topics(self, doc_indices: Optional[List[int]] = None) -> pd.DataFrame:
        """Get document-topic assignments."""
        if self.topic_labels_ is None:
            raise ValueError("Model not fitted")
        
        if doc_indices is None:
            doc_indices = list(range(len(self.topic_labels_)))
        
        data = []
        for idx in doc_indices:
            topic = self.get_topic(self.topic_labels_[idx])
            data.append({
                'Document': idx,
                'Topic': self.topic_labels_[idx],
                'Label': topic.label if topic else "",
                'Preview': self.documents_[idx][:100] + "..."
            })
        return pd.DataFrame(data)
    
    def get_archetypes(self, topic_id: int) -> Optional[Dict]:
        """Get archetype documents for a topic."""
        topic = self.get_topic(topic_id)
        if topic is None or topic.archetypes is None:
            return None
        
        return {
            'indices': topic.archetypes,
            'texts': topic.archetype_texts,
            'method': self.config.archetype_method,
            'count': len(topic.archetypes)
        }
    
    def generate_labels(self, labeler) -> None:
        """Generate labels using LLM."""
        if self.topics_ is None:
            raise ValueError("Model not fitted")
        
        for t in self.topics_:
            if t.topic_id >= 0:
                t.label = labeler.generate_label(t.keywords, t.representative_texts)
            else:
                t.label = "Outliers"
    
    def evaluate(self) -> Dict[str, float]:
        """Evaluate model quality."""
        if self.topics_ is None:
            raise ValueError("Model not fitted")
        
        all_kw = [k for t in self.topics_ if t.topic_id >= 0 for k in t.keywords[:10]]
        diversity = len(set(all_kw)) / max(len(all_kw), 1)
        
        return {
            'n_topics': self.n_topics_,
            'outlier_ratio': self.outlier_count_ / len(self.topic_labels_),
            'diversity': diversity
        }
    
    def visualize(self, method: str = "umap", **kwargs):
        """Visualize topics in 2D."""
        from .visualization import create_topic_visualization
        return create_topic_visualization(
            self.embeddings_, self.topic_labels_,
            self.topics_, self.documents_, method, **kwargs
        )
    
    def visualize_topics(self, **kwargs):
        """Visualize topic keywords."""
        from .visualization import create_topic_barchart
        return create_topic_barchart(self.topics_, **kwargs)
    
    def visualize_hierarchy(self, **kwargs):
        """Visualize topic hierarchy."""
        from .visualization import create_topic_hierarchy
        return create_topic_hierarchy(
            self.embeddings_, self.topic_labels_, self.topics_, **kwargs
        )
    
    def save(self, path: Union[str, Path]):
        """Save model."""
        with open(path, 'wb') as f:
            pickle.dump({
                'config': self.config,
                'documents_': self.documents_,
                'embeddings_': self.embeddings_,
                'topic_labels_': self.topic_labels_,
                'topics_': self.topics_,
                'n_topics_': self.n_topics_,
                'outlier_count_': self.outlier_count_,
                'detected_language_': self.detected_language_,
            }, f)
    
    @classmethod
    def load(cls, path: Union[str, Path]) -> "TriTopic":
        """Load model."""
        with open(path, 'rb') as f:
            state = pickle.load(f)
        
        model = cls(config=state['config'])
        for k, v in state.items():
            if k != 'config':
                setattr(model, k, v)
        
        if model.documents_:
            model._initialize_components(model.documents_)
        return model
    
    def __repr__(self):
        if self.topics_ is None:
            return "TriTopic(not fitted)"
        return f"TriTopic(n_topics={self.n_topics_}, n_docs={len(self.documents_)})"
