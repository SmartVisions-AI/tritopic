"""Visualization functions for TriTopic."""

import numpy as np
from typing import List, Optional


def create_topic_visualization(
    embeddings: np.ndarray,
    labels: np.ndarray,
    topics: List,
    documents: List[str],
    method: str = "umap",
    **kwargs
):
    """Create 2D topic visualization."""
    import plotly.express as px
    
    # Reduce to 2D
    if method == "umap":
        from umap import UMAP
        reducer = UMAP(n_components=2, random_state=42, **kwargs)
    else:
        from sklearn.manifold import TSNE
        reducer = TSNE(n_components=2, random_state=42, **kwargs)
    
    coords = reducer.fit_transform(embeddings)
    
    # Create labels
    topic_names = {t.topic_id: t.label or f"Topic {t.topic_id}" for t in topics}
    topic_names[-1] = "Outliers"
    
    fig = px.scatter(
        x=coords[:, 0], y=coords[:, 1],
        color=[topic_names.get(l, "Unknown") for l in labels],
        hover_data={'text': [d[:100] + "..." for d in documents]},
        title="TriTopic Document Map"
    )
    fig.update_layout(legend_title="Topics")
    return fig


def create_topic_barchart(topics: List, n_words: int = 10, **kwargs):
    """Create topic keyword barchart."""
    import plotly.graph_objects as go
    from plotly.subplots import make_subplots
    
    valid_topics = [t for t in topics if t.topic_id >= 0][:12]
    n_topics = len(valid_topics)
    
    if n_topics == 0:
        return go.Figure()
    
    rows = (n_topics + 2) // 3
    fig = make_subplots(rows=rows, cols=3, subplot_titles=[
        t.label or f"Topic {t.topic_id}" for t in valid_topics
    ])
    
    for i, topic in enumerate(valid_topics):
        row, col = i // 3 + 1, i % 3 + 1
        words = topic.keywords[:n_words][::-1]
        scores = topic.keyword_scores[:n_words][::-1]
        
        fig.add_trace(
            go.Bar(x=scores, y=words, orientation='h', showlegend=False),
            row=row, col=col
        )
    
    fig.update_layout(height=300 * rows, title="Topic Keywords")
    return fig


def create_topic_hierarchy(
    embeddings: np.ndarray,
    labels: np.ndarray,
    topics: List,
    **kwargs
):
    """Create topic hierarchy dendrogram."""
    import plotly.figure_factory as ff
    from scipy.cluster.hierarchy import linkage
    from scipy.spatial.distance import pdist
    
    valid_topics = [t for t in topics if t.topic_id >= 0 and t.centroid is not None]
    if len(valid_topics) < 2:
        import plotly.graph_objects as go
        return go.Figure()
    
    centroids = np.array([t.centroid for t in valid_topics])
    labels_list = [t.label or f"Topic {t.topic_id}" for t in valid_topics]
    
    fig = ff.create_dendrogram(
        centroids,
        labels=labels_list,
        linkagefun=lambda x: linkage(pdist(x), method='ward')
    )
    fig.update_layout(title="Topic Hierarchy")
    return fig
