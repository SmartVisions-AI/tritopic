"""Embedding Engine for document vectorization."""

import numpy as np
from typing import List


class EmbeddingEngine:
    """Generate document embeddings using sentence transformers."""
    
    def __init__(
        self,
        model_name: str = "all-MiniLM-L6-v2",
        batch_size: int = 32,
        device: str = "cpu"
    ):
        self.model_name = model_name
        self.batch_size = batch_size
        self.device = device
        self._model = None
    
    def _load_model(self):
        """Lazy load the model."""
        if self._model is None:
            from sentence_transformers import SentenceTransformer
            self._model = SentenceTransformer(self.model_name, device=self.device)
    
    def encode(self, documents: List[str], show_progress: bool = True) -> np.ndarray:
        """Encode documents to dense vectors."""
        self._load_model()
        return self._model.encode(
            documents,
            batch_size=self.batch_size,
            show_progress_bar=show_progress,
            convert_to_numpy=True
        )
    
    @property
    def embedding_dim(self) -> int:
        """Get embedding dimension."""
        self._load_model()
        return self._model.get_sentence_embedding_dimension()
