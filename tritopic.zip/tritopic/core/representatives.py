"""Representative document selection with archetype support."""

import numpy as np
from typing import Dict, List, Optional


class RepresentativeSelector:
    """Select representative documents and archetypes."""
    
    def __init__(
        self,
        method: str = "hybrid",
        n_representatives: int = 5,
        n_archetypes: int = 4,
        archetype_method: str = "furthest_sum"
    ):
        self.method = method
        self.n_representatives = n_representatives
        self.n_archetypes = n_archetypes
        self.archetype_method = archetype_method
    
    def select(
        self,
        embeddings: np.ndarray,
        documents: List[str],
        keywords: List[str],
        indices: np.ndarray
    ) -> Dict:
        """Select representative documents and archetypes."""
        n_docs = len(documents)
        if n_docs == 0:
            return {'indices': [], 'texts': [], 'archetype_indices': [], 'archetype_texts': []}
        
        n_reps = min(self.n_representatives, n_docs)
        n_arch = min(self.n_archetypes, n_docs) if self.n_archetypes > 0 else 0
        
        # Centroid-based representatives
        centroid = np.mean(embeddings, axis=0)
        distances = np.linalg.norm(embeddings - centroid, axis=1)
        rep_local_idx = np.argsort(distances)[:n_reps]
        
        rep_indices = [int(indices[i]) for i in rep_local_idx]
        rep_texts = [documents[i] for i in rep_local_idx]
        
        # Archetypes (diverse extremes)
        arch_indices = []
        arch_texts = []
        
        if n_arch > 0 and n_docs >= n_arch:
            arch_local_idx = self._find_archetypes(embeddings, n_arch)
            arch_indices = [int(indices[i]) for i in arch_local_idx]
            arch_texts = [documents[i] for i in arch_local_idx]
        
        return {
            'indices': rep_indices,
            'texts': rep_texts,
            'archetype_indices': arch_indices,
            'archetype_texts': arch_texts
        }
    
    def _find_archetypes(self, embeddings: np.ndarray, n_archetypes: int) -> List[int]:
        """Find archetype documents using furthest-sum algorithm."""
        n_samples = embeddings.shape[0]
        if n_samples <= n_archetypes:
            return list(range(n_samples))
        
        # Start with point furthest from centroid
        centroid = np.mean(embeddings, axis=0)
        distances = np.linalg.norm(embeddings - centroid, axis=1)
        selected = [int(np.argmax(distances))]
        
        # Iteratively add furthest point from selected set
        for _ in range(n_archetypes - 1):
            min_distances = np.full(n_samples, np.inf)
            for idx in selected:
                dists = np.linalg.norm(embeddings - embeddings[idx], axis=1)
                min_distances = np.minimum(min_distances, dists)
            min_distances[selected] = -1
            selected.append(int(np.argmax(min_distances)))
        
        return selected
