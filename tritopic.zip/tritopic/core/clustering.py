"""Consensus Leiden Clustering."""

import numpy as np
from scipy import sparse
from typing import Optional


class ConsensusLeiden:
    """Leiden clustering with consensus for stability."""
    
    def __init__(
        self,
        resolution: float = 1.0,
        n_runs: int = 10,
        min_cluster_size: int = 5,
        random_state: Optional[int] = 42
    ):
        self.resolution = resolution
        self.n_runs = n_runs
        self.min_cluster_size = min_cluster_size
        self.random_state = random_state
    
    def fit_predict(self, graph: sparse.csr_matrix) -> np.ndarray:
        """Cluster graph using consensus Leiden."""
        import igraph as ig
        import leidenalg
        
        sources, targets = graph.nonzero()
        weights = np.array(graph[sources, targets]).flatten()
        
        g = ig.Graph(n=graph.shape[0], edges=list(zip(sources, targets)), directed=False)
        g.es['weight'] = weights
        
        all_labels = []
        for run in range(self.n_runs):
            seed = self.random_state + run if self.random_state else None
            partition = leidenalg.find_partition(
                g, leidenalg.RBConfigurationVertexPartition,
                weights='weight', resolution_parameter=self.resolution,
                seed=seed
            )
            all_labels.append(np.array(partition.membership))
        
        if self.n_runs == 1:
            labels = all_labels[0]
        else:
            labels = self._consensus_labels(all_labels, graph.shape[0])
        
        labels = self._handle_small_clusters(labels)
        return labels
    
    def _consensus_labels(self, all_labels: list, n_samples: int) -> np.ndarray:
        """Create consensus from multiple runs."""
        co_matrix = np.zeros((n_samples, n_samples))
        for labels in all_labels:
            for i in range(n_samples):
                mask = labels == labels[i]
                co_matrix[i, mask] += 1
        co_matrix /= self.n_runs
        
        import igraph as ig
        import leidenalg
        
        g = ig.Graph.Weighted_Adjacency(co_matrix.tolist(), mode='undirected')
        partition = leidenalg.find_partition(
            g, leidenalg.RBConfigurationVertexPartition,
            weights='weight', resolution_parameter=self.resolution,
            seed=self.random_state
        )
        return np.array(partition.membership)
    
    def _handle_small_clusters(self, labels: np.ndarray) -> np.ndarray:
        """Mark small clusters as outliers."""
        unique, counts = np.unique(labels, return_counts=True)
        small_clusters = unique[counts < self.min_cluster_size]
        
        result = labels.copy()
        for c in small_clusters:
            result[labels == c] = -1
        
        # Renumber
        old_labels = np.unique(result[result >= 0])
        label_map = {old: new for new, old in enumerate(old_labels)}
        label_map[-1] = -1
        return np.array([label_map[l] for l in result])
