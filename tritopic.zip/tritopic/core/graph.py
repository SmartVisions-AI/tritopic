"""Graph construction for topic modeling."""

import numpy as np
from scipy import sparse
from sklearn.neighbors import NearestNeighbors
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from typing import List, Optional, Tuple
import pandas as pd


class GraphBuilder:
    """Build similarity graphs from embeddings."""
    
    def __init__(
        self,
        n_neighbors: int = 15,
        metric: str = "cosine",
        graph_type: str = "hybrid",
        snn_weight: float = 0.5
    ):
        self.n_neighbors = n_neighbors
        self.metric = metric
        self.graph_type = graph_type
        self.snn_weight = snn_weight
    
    def build(self, embeddings: np.ndarray) -> sparse.csr_matrix:
        """Build similarity graph from embeddings."""
        n_samples = embeddings.shape[0]
        k = min(self.n_neighbors, n_samples - 1)
        
        nn = NearestNeighbors(n_neighbors=k + 1, metric=self.metric)
        nn.fit(embeddings)
        distances, indices = nn.kneighbors(embeddings)
        
        distances = distances[:, 1:]
        indices = indices[:, 1:]
        
        if self.graph_type == "knn":
            return self._build_knn_graph(n_samples, indices, distances)
        elif self.graph_type == "mutual_knn":
            return self._build_mutual_knn_graph(n_samples, indices, distances)
        elif self.graph_type == "snn":
            return self._build_snn_graph(n_samples, indices)
        elif self.graph_type == "hybrid":
            return self._build_hybrid_graph(n_samples, indices, distances)
        else:
            raise ValueError(f"Unknown graph type: {self.graph_type}")
    
    def _build_knn_graph(self, n_samples, indices, distances):
        rows, cols, data = [], [], []
        for i in range(n_samples):
            for j, d in zip(indices[i], distances[i]):
                rows.append(i)
                cols.append(j)
                data.append(1.0 / (1.0 + d))
        graph = sparse.csr_matrix((data, (rows, cols)), shape=(n_samples, n_samples))
        return (graph + graph.T) / 2
    
    def _build_mutual_knn_graph(self, n_samples, indices, distances):
        neighbor_sets = [set(indices[i]) for i in range(n_samples)]
        rows, cols, data = [], [], []
        for i in range(n_samples):
            for idx, (j, d) in enumerate(zip(indices[i], distances[i])):
                if i in neighbor_sets[j]:
                    rows.append(i)
                    cols.append(j)
                    data.append(1.0 / (1.0 + d))
        graph = sparse.csr_matrix((data, (rows, cols)), shape=(n_samples, n_samples))
        return (graph + graph.T) / 2
    
    def _build_snn_graph(self, n_samples, indices):
        neighbor_sets = [set(indices[i]) for i in range(n_samples)]
        k = indices.shape[1]
        rows, cols, data = [], [], []
        for i in range(n_samples):
            for j in indices[i]:
                if j > i:
                    shared = len(neighbor_sets[i] & neighbor_sets[j])
                    if shared > 0:
                        similarity = shared / k
                        rows.extend([i, j])
                        cols.extend([j, i])
                        data.extend([similarity, similarity])
        return sparse.csr_matrix((data, (rows, cols)), shape=(n_samples, n_samples))
    
    def _build_hybrid_graph(self, n_samples, indices, distances):
        mknn = self._build_mutual_knn_graph(n_samples, indices, distances)
        snn = self._build_snn_graph(n_samples, indices)
        mknn_max = mknn.max() if mknn.nnz > 0 else 1.0
        snn_max = snn.max() if snn.nnz > 0 else 1.0
        if mknn_max > 0:
            mknn = mknn / mknn_max
        if snn_max > 0:
            snn = snn / snn_max
        return (1 - self.snn_weight) * mknn + self.snn_weight * snn


class MultiViewGraphBuilder(GraphBuilder):
    """Multi-view graph builder combining semantic, lexical, and metadata views."""
    
    def __init__(
        self,
        n_neighbors: int = 15,
        metric: str = "cosine",
        graph_type: str = "hybrid",
        snn_weight: float = 0.5,
        semantic_weight: float = 0.5,
        lexical_weight: float = 0.3,
        metadata_weight: float = 0.2,
        use_lexical: bool = True,
        use_metadata: bool = False,
        lexical_method: str = "tfidf",
        ngram_range: Tuple[int, int] = (1, 2)
    ):
        super().__init__(n_neighbors, metric, graph_type, snn_weight)
        self.semantic_weight = semantic_weight
        self.lexical_weight = lexical_weight
        self.metadata_weight = metadata_weight
        self.use_lexical = use_lexical
        self.use_metadata = use_metadata
        self.lexical_method = lexical_method
        self.ngram_range = ngram_range
    
    def build(
        self,
        embeddings: np.ndarray,
        documents: List[str],
        metadata: Optional[pd.DataFrame] = None
    ) -> sparse.csr_matrix:
        """Build multi-view graph."""
        n_samples = embeddings.shape[0]
        semantic_graph = super().build(embeddings)
        combined = self.semantic_weight * semantic_graph
        
        if self.use_lexical:
            lexical_graph = self._build_lexical_graph(documents, n_samples)
            combined = combined + self.lexical_weight * lexical_graph
        
        if self.use_metadata and metadata is not None:
            metadata_graph = self._build_metadata_graph(metadata, n_samples)
            combined = combined + self.metadata_weight * metadata_graph
        
        max_val = combined.max()
        if max_val > 0:
            combined = combined / max_val
        
        return combined
    
    def _build_lexical_graph(self, documents: List[str], n_samples: int) -> sparse.csr_matrix:
        vectorizer = TfidfVectorizer(
            max_df=0.95, min_df=2, max_features=5000,
            ngram_range=self.ngram_range, stop_words='english'
        )
        try:
            tfidf_matrix = vectorizer.fit_transform(documents)
        except ValueError:
            return sparse.csr_matrix((n_samples, n_samples))
        
        similarity = cosine_similarity(tfidf_matrix)
        threshold = np.percentile(similarity[similarity > 0], 80)
        similarity[similarity < threshold] = 0
        return sparse.csr_matrix(similarity)
    
    def _build_metadata_graph(self, metadata: pd.DataFrame, n_samples: int) -> sparse.csr_matrix:
        from sklearn.preprocessing import OneHotEncoder
        categorical_cols = metadata.select_dtypes(include=['object', 'category']).columns
        if len(categorical_cols) == 0:
            return sparse.csr_matrix((n_samples, n_samples))
        encoder = OneHotEncoder(sparse_output=True, handle_unknown='ignore')
        encoded = encoder.fit_transform(metadata[categorical_cols])
        return sparse.csr_matrix(cosine_similarity(encoded))
