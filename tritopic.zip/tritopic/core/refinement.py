"""Embedding refinement for iterative topic modeling."""

import numpy as np


class EmbeddingRefiner:
    """Refine embeddings based on topic assignments."""
    
    def __init__(self, strength: float = 0.15):
        self.strength = strength
    
    def refine(self, embeddings: np.ndarray, labels: np.ndarray) -> np.ndarray:
        """Pull embeddings toward their topic centroids."""
        refined = embeddings.copy()
        
        for label in np.unique(labels):
            if label < 0:
                continue
            mask = labels == label
            centroid = np.mean(embeddings[mask], axis=0)
            refined[mask] = (1 - self.strength) * embeddings[mask] + self.strength * centroid
        
        return refined
