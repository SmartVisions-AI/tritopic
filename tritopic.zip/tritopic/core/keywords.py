"""Keyword extraction for topics."""

import numpy as np
from typing import List, Tuple
from sklearn.feature_extraction.text import TfidfVectorizer, CountVectorizer


class KeywordExtractor:
    """Extract keywords using c-TF-IDF."""
    
    def __init__(
        self,
        method: str = "ctfidf",
        n_keywords: int = 10,
        language: str = "en",
        ngram_range: Tuple[int, int] = (1, 2)
    ):
        self.method = method
        self.n_keywords = n_keywords
        self.language = language
        self.ngram_range = ngram_range
    
    def extract(self, topic_docs: List[str], all_docs: List[str]) -> Tuple[List[str], List[float]]:
        """Extract keywords from topic documents."""
        if not topic_docs:
            return [], []
        
        stop_words = 'english' if self.language == 'en' else None
        
        # Fit on all docs for IDF
        tfidf = TfidfVectorizer(
            max_df=0.95, min_df=1, max_features=5000,
            ngram_range=self.ngram_range, stop_words=stop_words
        )
        
        try:
            tfidf.fit(all_docs)
        except ValueError:
            return [], []
        
        # Transform topic docs
        topic_text = " ".join(topic_docs)
        topic_vector = tfidf.transform([topic_text]).toarray()[0]
        
        # Get top keywords
        feature_names = tfidf.get_feature_names_out()
        top_indices = topic_vector.argsort()[-self.n_keywords:][::-1]
        
        keywords = [feature_names[i] for i in top_indices if topic_vector[i] > 0]
        scores = [float(topic_vector[i]) for i in top_indices if topic_vector[i] > 0]
        
        return keywords[:self.n_keywords], scores[:self.n_keywords]
