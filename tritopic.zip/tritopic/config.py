"""
TriTopic Configuration Module

Defines all configuration parameters for the TriTopic model.
FIXED: Added missing 'device' attribute
"""

from dataclasses import dataclass, field
from typing import Optional, List, Literal, Union


@dataclass
class TriTopicConfig:
    """
    Configuration for TriTopic model.
    """
    
    # === Embedding & Language Settings ===
    embedding_model: str = "auto"
    embedding_batch_size: int = 32
    device: str = "cpu"  # <-- THIS WAS MISSING!
    language: str = "auto"
    multilingual: bool = False
    language_detection_sample: int = 100
    tokenizer: str = "auto"
    custom_stopwords: Optional[List[str]] = None
    min_token_length: int = 2
    max_token_length: int = 50
    
    # === Graph Construction ===
    n_neighbors: int = 15
    metric: str = "cosine"
    graph_type: Literal["knn", "mutual_knn", "snn", "hybrid"] = "hybrid"
    snn_weight: float = 0.5
    
    # === Multi-View Fusion ===
    use_lexical_view: bool = True
    use_metadata_view: bool = False
    semantic_weight: float = 0.5
    lexical_weight: float = 0.3
    metadata_weight: float = 0.2
    lexical_method: Literal["tfidf", "bm25"] = "tfidf"
    ngram_range: tuple = (1, 2)
    
    # === Clustering ===
    resolution: float = 1.0
    n_consensus_runs: int = 10
    min_cluster_size: int = 5
    
    # === Iterative Refinement ===
    use_iterative_refinement: bool = True
    max_iterations: int = 5
    convergence_threshold: float = 0.95
    refinement_strength: float = 0.15
    
    # === Keywords ===
    n_keywords: int = 10
    keyword_method: Literal["ctfidf", "bm25", "keybert"] = "ctfidf"
    
    # === Representative Documents ===
    n_representative_docs: int = 5
    representative_method: Literal["centroid", "medoid", "archetype", "diverse", "hybrid"] = "hybrid"
    n_archetypes: int = 4
    archetype_method: Literal["pcha", "convex_hull", "furthest_sum"] = "furthest_sum"
    
    # === Outlier Handling ===
    outlier_threshold: float = 0.1
    reassign_outliers: bool = False
    
    # === Misc ===
    random_state: Optional[int] = 42
    verbose: bool = True
    n_jobs: int = -1
    
    def __post_init__(self):
        """Validate configuration after initialization."""
        self._validate()
    
    def _validate(self):
        """Validate configuration parameters."""
        # Weights should sum to ~1.0
        total_weight = self.semantic_weight
        if self.use_lexical_view:
            total_weight += self.lexical_weight
        if self.use_metadata_view:
            total_weight += self.metadata_weight
        
        if abs(total_weight - 1.0) > 0.01:
            # Auto-normalize weights
            if self.use_lexical_view and self.use_metadata_view:
                self.semantic_weight = self.semantic_weight / total_weight
                self.lexical_weight = self.lexical_weight / total_weight
                self.metadata_weight = self.metadata_weight / total_weight
            elif self.use_lexical_view:
                total = self.semantic_weight + self.lexical_weight
                self.semantic_weight = self.semantic_weight / total
                self.lexical_weight = self.lexical_weight / total
            else:
                self.semantic_weight = 1.0
        
        # Validate ranges
        assert 0 < self.n_neighbors <= 100, "n_neighbors must be between 1 and 100"
        assert 0 < self.snn_weight <= 1, "snn_weight must be between 0 and 1"
        assert 0 < self.resolution <= 5, "resolution must be between 0 and 5"
        assert 0 < self.convergence_threshold <= 1, "convergence_threshold must be between 0 and 1"
        assert self.n_archetypes >= 2, "n_archetypes must be at least 2"
    
    def get_embedding_model_for_language(self, detected_language: str = None) -> str:
        """Get the appropriate embedding model based on language settings."""
        if self.embedding_model != "auto":
            return self.embedding_model
        
        lang = detected_language or self.language
        
        if self.multilingual:
            return "paraphrase-multilingual-mpnet-base-v2"
        
        model_map = {
            "en": "all-MiniLM-L6-v2",
            "zh": "BAAI/bge-base-zh-v1.5",
            "ja": "paraphrase-multilingual-MiniLM-L12-v2",
            "ko": "paraphrase-multilingual-MiniLM-L12-v2",
        }
        
        if lang in model_map:
            return model_map[lang]
        elif lang != "en" and lang != "auto":
            return "paraphrase-multilingual-MiniLM-L12-v2"
        else:
            return "all-MiniLM-L6-v2"
    
    def to_dict(self) -> dict:
        """Convert config to dictionary."""
        return {k: v for k, v in self.__dict__.items() if not k.startswith('_')}
    
    @classmethod
    def from_dict(cls, config_dict: dict) -> "TriTopicConfig":
        """Create config from dictionary."""
        return cls(**config_dict)


# Predefined configurations
CONFIGS = {
    "default": TriTopicConfig(),
    
    "fast": TriTopicConfig(
        embedding_model="all-MiniLM-L6-v2",
        n_neighbors=10,
        n_consensus_runs=5,
        use_iterative_refinement=False,
        representative_method="centroid",
    ),
    
    "quality": TriTopicConfig(
        embedding_model="BAAI/bge-base-en-v1.5",
        n_neighbors=20,
        n_consensus_runs=20,
        max_iterations=10,
        representative_method="hybrid",
        n_archetypes=5,
    ),
    
    "multilingual": TriTopicConfig(
        multilingual=True,
        embedding_model="paraphrase-multilingual-mpnet-base-v2",
        semantic_weight=0.6,
        lexical_weight=0.2,
        metadata_weight=0.2,
    ),
    
    "german": TriTopicConfig(
        language="de",
        embedding_model="paraphrase-multilingual-MiniLM-L12-v2",
    ),
}


def get_config(name: str) -> TriTopicConfig:
    """Get predefined configuration by name."""
    if name not in CONFIGS:
        raise ValueError(f"Unknown config: {name}. Available: {list(CONFIGS.keys())}")
    return CONFIGS[name]
