"""Visualization components for TriTopic."""

from tritopic.visualization.plotter import TopicVisualizer

__all__ = ["TopicVisualizer"]
